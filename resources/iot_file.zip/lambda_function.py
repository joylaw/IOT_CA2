import boto3
import json
import pymysql

def lambda_handler(event, context):
    datetime = event['datetime']
    temperature = event['temperature']
    humidity = event['humidity']
    db = pymysql.connect(host = "iotca2.cmwnxcwvcz4v.us-west-2.rds.amazonaws.com", user="admin", passwd="!QWER4321", port=3306, db="iotca2")

    try:
        with db.cursor() as cur:
            cur.execute("INSERT into temp_humidity (date_time, temperature, humidity) VALUES ('{0}', '{1}', '{2}')".format(datetime, temperature, humidity))
            db.commit()
    except Exception, e:
        print (e)
        
    db.close()
    